package com.cg.prob4.controller;

public class Consumer {
	
	int consumerId;
	String consumerName;
	String consumerAddress;
	public Consumer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Consumer(int consumerId, String consumerName, String consumerAddress) {
		super();
		this.consumerId = consumerId;
		this.consumerName = consumerName;
		this.consumerAddress = consumerAddress;
	}
	@Override
	public String toString() {
		return "Consumer [consumerId=" + consumerId + ", consumerName=" + consumerName + ", consumerAddress="
				+ consumerAddress + "]";
	}
	public int getConsumerId() {
		return consumerId;
	}
	public void setConsumerId(int consumerId) {
		this.consumerId = consumerId;
	}
	public String getConsumerName() {
		return consumerName;
	}
	public void setConsumerName(String consumerName) {
		this.consumerName = consumerName;
	}
	public String getConsumerAddress() {
		return consumerAddress;
	}
	public void setConsumerAddress(String consumerAddress) {
		this.consumerAddress = consumerAddress;
	}
	
	
}
