package com.cg.prob4.controller;

import java.sql.Statement;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/displayDetails")
public class ServletClass extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			PrintWriter out = response.getWriter();
			Connection connection = null;
			PreparedStatement statement = null;
//			String number = request.getParameter("consumernumber");
			int id=Integer.parseInt(request.getParameter("consumernumber"));
			connection = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "Capgemini123");
			statement = connection.prepareStatement("select * from Consumers");
			out.println("<html><body><table>");
			out.println("<tr><th>Consumer Number</th><th>Consumer Name</th><th>Address</th></tr>");
			ResultSet rs = statement.executeQuery();
			while(rs.next()) {
				int num = rs.getInt("consumer_num");
				String name = rs.getString("consumer_name");
				String addr = rs.getString("address");
				out.println("<tr><td>"+num+"</td><td>"+name+"</td><td>"+addr+"</td><td><a href=\"show_bills.jsp\">Show bill details</a></td></tr>");
			}
			out.println("</table></body></html>");
			statement.close();
			connection.close();
		} catch(Exception e) {
			System.out.println("Exception occured");
		}
	}

}
