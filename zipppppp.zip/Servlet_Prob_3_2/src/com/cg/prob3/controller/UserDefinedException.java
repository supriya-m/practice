package com.cg.prob3.controller;

public class UserDefinedException extends Exception {
	public String toString() {
		String exceptionMessage = "LoginException";
		return exceptionMessage;
	}
}
