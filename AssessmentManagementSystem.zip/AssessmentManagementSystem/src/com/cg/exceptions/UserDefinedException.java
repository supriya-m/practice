package com.cg.exceptions;

public class UserDefinedException extends Exception{

	public String getMessage() {
		return "Problem occured while adding trainees";
	}
}
