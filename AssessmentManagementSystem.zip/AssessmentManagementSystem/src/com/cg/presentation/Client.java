package com.cg.presentation;

import java.util.Scanner;

import com.cg.dao.ITraineeDetailsDao;
import com.cg.dao.TraineeDetailsDao;
import com.cg.exceptions.UserDefinedException;
import com.cg.model.TraineeDetails;

public class Client {

	public static void main(String[] args) {
		
		ITraineeDetailsDao traineeDetailsDao = new TraineeDetailsDao();
		TraineeDetails traineeDetails = null;
		Scanner sc = new Scanner(System.in);
		UserDefinedException exception = new UserDefinedException();
		
		int traineesAdded = 0;
		
		System.out.println("Enter Trainee name");
		String traineeName = sc.next();
		
		System.out.println("Enter Module name");
		String moduleName = sc.next();
		
		System.out.println("Enter MPT Marks");
		int mptMarks = sc.nextInt();
		
		System.out.println("Enter MTT Marks");
		
		int mttMarks = sc.nextInt();
		System.out.println("Enter Assignment Marks");
		int assignmentMarks = sc.nextInt();
		
		int totalMarks = traineeDetailsDao.calculateTotalScore(mptMarks, mttMarks, assignmentMarks);
		
		traineeDetails = new TraineeDetails(traineeName, moduleName, mptMarks, mttMarks, assignmentMarks, totalMarks);
		
		traineesAdded = traineeDetailsDao.persistTraineeDetails(traineeDetails);
		
		if(traineesAdded > 0) {
			
			System.out.println("Total marks scored by trainee : " + totalMarks);
		
		} else {
			
			System.out.println(exception.getMessage());
		}
	}
}
