package com.cg.utility;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JPAUtility {

	static EntityManagerFactory factory = null;
	
	static {
		
		factory = Persistence.createEntityManagerFactory("AssessmentManagementSystem_PU");
	}

	public static EntityManagerFactory getFactory() {
		return factory;
	}

	public static void setFactory(EntityManagerFactory factory) {
		JPAUtility.factory = factory;
	}
	
	
}
