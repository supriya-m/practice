package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;

import com.cg.model.TraineeDetails;
import com.cg.utility.JPAUtility;

public class TraineeDetailsDao implements ITraineeDetailsDao{

	EntityManagerFactory factory = null;
	EntityManager manager = null;
	EntityTransaction transaction = null;
	
	@Override
	public int persistTraineeDetails(TraineeDetails traineeDetails) {
		int traineesInserted = 0;
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		transaction.begin();
		try {
			manager.persist(traineeDetails);
			transaction.commit();
			traineesInserted++;
		} catch(PersistenceException e) {
			System.out.println(e.getMessage());
			transaction.rollback();
		} finally {
			manager.close();
			factory.close();
		}
		return traineesInserted;
		
	}

	@Override
	public int calculateTotalScore(float mptScore, float mttScore, float assignmentScore) {
		
		int totalScore = (int)(0.7 * mptScore + 0.15 * mttScore + 0.15 * assignmentScore);
		return totalScore;
		
	}

}
