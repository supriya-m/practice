package com.cg.dao;

import com.cg.model.TraineeDetails;

public interface ITraineeDetailsDao {

	public int persistTraineeDetails(TraineeDetails traineeDetails);
	
	public int calculateTotalScore(float mptScore, float mttScore, float assignmentScore);

}
