package com.cg.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Trainee_Details")
public class TraineeDetails {

	@Id
	@GeneratedValue
	@Column(name = "details_id")
	private int detailsId;
	@Column(name = "trainee_name")
	private String traineeName;
	@Column(name = "module_name")
	private String moduleName;
	@Column(name = "Mpt_marks")
	private int mptScore;
	@Column(name = "mtt_marks")
	private int mttScore;
	@Column(name = "assignment_marks")
	private int assignmentScore;
	@Column(name = "total")
	private int totalScore;
	
	public TraineeDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TraineeDetails(String traineeName, String moduleName, int mptScore, int mttScore, int assignmentScore,
			int totalScore) {
		super();
		this.traineeName = traineeName;
		this.moduleName = moduleName;
		this.mptScore = mptScore;
		this.mttScore = mttScore;
		this.assignmentScore = assignmentScore;
		this.totalScore = totalScore;
	}

	public int getDetailsId() {
		return detailsId;
	}

	public void setDetailsId(int detailsId) {
		this.detailsId = detailsId;
	}

	public String getTraineeName() {
		return traineeName;
	}

	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}

	public String getModuleName() {
		return moduleName;
	}

	public void setModuleName(String moduleName) {
		this.moduleName = moduleName;
	}

	public int getMptScore() {
		return mptScore;
	}

	public void setMptScore(int mptScore) {
		this.mptScore = mptScore;
	}

	public int getMttScore() {
		return mttScore;
	}

	public void setMttScore(int mttScore) {
		this.mttScore = mttScore;
	}

	public int getAssignmentScore() {
		return assignmentScore;
	}

	public void setAssignmentScore(int assignmentScore) {
		this.assignmentScore = assignmentScore;
	}

	public int getTotalScore() {
		return totalScore;
	}

	public void setTotalScore(int totalScore) {
		this.totalScore = totalScore;
	}

	@Override
	public String toString() {
		return "TraineeDetails [detailsId=" + detailsId + ", traineeName=" + traineeName + ", moduleName=" + moduleName
				+ ", mptScore=" + mptScore + ", mttScore=" + mttScore + ", assignmentScore=" + assignmentScore
				+ ", totalScore=" + totalScore + "]";
	}
	
}
