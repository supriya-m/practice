package com.cg.prob2.dao;

import java.util.List;

import com.cg.prob2.dto.Book;

public interface ImplBookAuthorDAO {
	
	public List<Book> getBookList(Book book); 
}
