package com.cg.prob2.dao;

import java.util.List;

import com.cg.prob2.dto.Book;


public class ClientMain {
	public static void main(String[] args) {

		ImplBookAuthorDAO badao = new BookAuthorDAO();
		Book book = new Book();
		List<Book> getList = badao.getBookList(book);
		for(Book b : getList) {
			System.out.println(b);
		}
	}
}
