package com.cg.prob2.dao;

import java.util.List; 
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.TypedQuery;

import com.cg.prob2.dto.Book;
import com.cg.prob2.util.JPAUtility;

public class BookAuthorDAO implements ImplBookAuthorDAO {
	EntityManagerFactory factory = null;
	EntityManager manager = null;
	@Override
	public List<Book> getBookList(Book book) {
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		final String bookquery = "select b.BookTitle from book_table b";
		TypedQuery<Book> query = manager.createQuery(bookquery,Book.class);
		List<Book> booklist = query.getResultList();
		return booklist;
	}

}
