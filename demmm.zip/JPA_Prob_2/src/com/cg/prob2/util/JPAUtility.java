package com.cg.prob2.util;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class JPAUtility {
	static EntityManagerFactory factory = null;
	static {
		factory = Persistence.createEntityManagerFactory("Book_publishing");
	}
	public static EntityManagerFactory getFactory() {
		return factory;
	}
}

