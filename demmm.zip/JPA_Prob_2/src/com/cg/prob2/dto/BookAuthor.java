package com.cg.prob2.dto;

import javax.persistence.Table;

@Table(name="book_author_table")
public class BookAuthor {
	Book book;
	Author author;
	
}
