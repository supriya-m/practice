package com.cg.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/insertDetails")
public class Servlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			PrintWriter out = resp.getWriter();
			String name = req.getParameter("myname");
			int id = Integer.parseInt(req.getParameter("myid"));
			Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "Capgemini123");
//INSERT INTO TABLE
			PreparedStatement st = conn.prepareStatement("insert into db values(?,?)");
			st.setString(1, name);
			st.setInt(2, id);
			st.executeUpdate();
			out.println("<html><body><b>Success</b></body></html>");

//DELETE FROM TABLE
//			PreparedStatement st = conn.prepareStatement("delete from db where name=?");
//			st.setString(1, name);
//			st.executeUpdate();
//			out.println("<html><body><b>Deleted Successfully</b></body></html>");
//DISPLAY TABLE DETAILS ON BROWSER
			PreparedStatement st1 = conn.prepareStatement("select * from db");
			out.println("<html><body><table>");
			out.println("<tr><th>Name</th><th>Id</th></tr>");
			ResultSet rs = st1.executeQuery();
			while(rs.next()) {
				String displayName = rs.getString("name");
				int displayId = rs.getInt("id");
				out.println("<tr><td>"+displayName+"</td><td>"+displayId+"</td></tr>");
			}
			out.println("</table></body></html>");
			st1.close();
			st.close();
			conn.close();
		}
		catch(Exception e) {
			System.out.println("Exception occured");
		}
	}
}
