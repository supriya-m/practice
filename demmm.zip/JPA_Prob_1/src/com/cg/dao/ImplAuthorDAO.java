package com.cg.dao;

import com.cg.dto.Author;

public interface ImplAuthorDAO {
	
	public int addAuthor(Author author);
	
	public Author updateAuthor(Author author);
	
	public int deleteAuthor(int id);
	
	public Author findAuthor(int id);
}
