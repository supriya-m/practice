package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceException;

import com.cg.dto.Author;
import com.cg.util.JPAUtility;

public class AuthorDAO implements ImplAuthorDAO {
	
	EntityManagerFactory factory = null;
	EntityManager manager = null;
	EntityTransaction transaction = null;

	@Override
	public int addAuthor(Author author) {
		
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		transaction.begin();
		try {
			manager.persist(author);
			transaction.commit();
		}
		catch(PersistenceException e) {
			transaction.rollback();
			System.out.println(e.getMessage());
		}
		finally {
			manager.close();
			factory.close();
		}
		return author.getId();
	}

	@Override
	public Author updateAuthor(Author author) {
		
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		transaction.begin();
		
		Author authinfo = manager.find(Author.class, author.getId());
		authinfo.setFirstname(author.getFirstname());
		authinfo.setMiddlename(author.getMiddlename());
		authinfo.setLastname(author.getLastname());
		authinfo.setPhonenumber(author.getPhonenumber());
		
		transaction.commit();
		return authinfo;
	}

	@Override
	public int deleteAuthor(int id) {
		int i=0;
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		transaction = manager.getTransaction();
		transaction.begin();
		Author author = null;
		try {
			author = manager.find(Author.class, id);
			manager.remove(author);
			transaction.commit();
			i++;
		}
		catch(Exception e) {
			transaction.rollback();
			System.out.println(e.getMessage());
		}
		return 1;
	}

	@Override
	public Author findAuthor(int id) {
		factory = JPAUtility.getFactory();
		manager = factory.createEntityManager();
		Author author = null;
		try {
			author = manager.find(Author.class, id);
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
		}finally {
			manager.close();
			factory.close();
		}
		return author;
	}
	
	
}
