package com.cg.dao;

import java.util.Scanner;
import com.cg.dto.Author;
public class ClientMain {
	public static void main(String[] args) {
		
		ImplAuthorDAO authdao = new AuthorDAO();
		Scanner sc = new Scanner(System.in);
		
		int choice,i=0;
		String ans="";
		do {
			System.out.println("**--Welcome--**");
			System.out.println("Select one option:\n1)Insert into author_bu table\n2)Update author_bu table\n3)Delete from author_bu table\n4)Get Author details");
				choice = sc.nextInt();
				switch(choice) {
				case 1:
					System.out.print("Enter First Name of Author: ");
					String fname = sc.next();
					System.out.print("Enter Middle Name of Author: ");
					String mname = sc.next();
					System.out.print("Enter Last Name of Author: ");
					String lname = sc.next();
					System.out.print("Enter Phone Number of Author: ");
					long phno = sc.nextLong();
					
					Author author = new Author(fname,mname,lname,phno);
					int id = authdao.addAuthor(author);
					System.out.println("Author with FirstName "+fname+" has been inserted into table with id "+id);
					break;
				case 2:
					System.out.print("Enter AuthorId to update:");
					int id1 = sc.nextInt();
					System.out.print("Enter updated FirstName: ");
					String updatefname = sc.next();
					System.out.print("Enter updated MiddleName: ");
					String updatemname = sc.next();
					System.out.print("Enter updated LastName: ");
					String updatelname = sc.next();
					System.out.print("Enter updated PhoneNumber: ");
					long updatephno = sc.nextLong();
					
					Author author1 = new Author(id1,updatefname,updatemname,updatelname,updatephno);
					Author updateAuthor = authdao.updateAuthor(author1);
					System.out.println("Author with id "+id1+" has been updated");
					System.out.println("Updated details:\nAuthorId:"+id1+"\n"+"Author FirstName:"+updatefname+"\n"+"Author MiddleName:"+updatemname+"\n"+"Author LastName:"+updatelname+"\n"+"Author PhoneNumber:"+updatephno+"\n");
					break;
				case 3:
					System.out.print("Enter AuthorId to delete:");
					int id2 = sc.nextInt();
					int delete =authdao.deleteAuthor(id2);
					System.out.println("Author details with AuthorId "+id2+" have been deleted");
					break;
				case 4:
					System.out.print("Enter AuthorId to get details of Author:");
					int id3 = sc.nextInt();
					Author author2 = new Author();
					Author find = authdao.findAuthor(id3);
					System.out.println("Details of "+author2.getFirstname()+" with id "+id3+":");
					System.out.print(find);
					break;
				default:
					System.out.println("**Enter proper choice**");
				}
				System.out.println("Do you want to continue?\nEnter yes or no");
				ans=sc.next();
		}while(ans.equalsIgnoreCase("yes") || ans.equalsIgnoreCase("y"));
		System.out.println("Thank you");
		}
}
